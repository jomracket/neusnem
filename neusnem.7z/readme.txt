NewSneM v0.1
------------


NewSneM is a SNES emulator for Windows. It was aiming for cycle accuracy, but completely failed.
Still, it's better than old SNeM was.
Nearly every component is missing features/has bugs, so don't moan if your favourite games don't
work.


Controls
--------

Up - Up
Down - Down
Left - Left
Right - Right
Enter - Start
S - A
X - B
A - X
Z - Y
Q - L
W - R


Very incomplete compatibility list
----------------------------------

Games that work -

Cameltry
Chrono Trigger (bad sound effects)
Earthbound
Mystical Ninja
Plok
Secret of Mana
Shadowrun
Soccer Kid
Super BC Kid
Super Bomberman
Super Mario Allstars
Super Mario World
Super Metroid
Super SWIV


Games that don't work -

Donkey Kong Country
Equinox
Seiken Densetsu 3


Tom Walker
tommowalker@yahoo.co.uk